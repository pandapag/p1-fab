from flask import Flask, render_template, request, redirect, url_for, jsonify
import json
from flask_pymongo import PyMongo
from bson import ObjectId

app = Flask(__name__)
app.config["MONGO_URI"] = "mongodb+srv://joaovitorfff:1234@cluster0.3bo2jrl.mongodb.net/faab?retryWrites=true&w=majority&appName=Cluster0"
mongo = PyMongo(app)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/create', methods=['POST'])
def create():
    if mongo.db is None:
        return "Não foi possível conectar ao banco de dados", 500
    user = {
        'nome': request.form['nome'],
        'senha': request.form['senha'],
        'email': request.form['email']
    }
    mongo.db.usuarios.insert_one(user)
    return redirect(url_for('home'))

@app.route('/update', methods=['POST'])
def update():
    user_id = request.form['id']
    updated_data = {
        'nome': request.form['nome'],
        'senha': request.form['senha'],
        'email': request.form['email']
    }
    updated_data = {k: v for k, v in updated_data.items() if v}
    mongo.db.usuarios.update_one({'_id': ObjectId(user_id)}, {'$set': updated_data})
    return redirect(url_for('home'))

@app.route('/delete', methods=['POST'])
def delete():
    user_id = request.form['delId']
    mongo.db.usuarios.delete_one({'_id': ObjectId(user_id)})
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)