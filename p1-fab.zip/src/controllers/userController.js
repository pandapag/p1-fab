const UserRepository = require('../repositories/UserRepository');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

class UserController {
    async register(req, res) {
        const { username, password } = req.body;
        const hashedPassword = await bcrypt.hash(password, 8);

        try {
            const user = await UserRepository.create({
                username,
                password: hashedPassword
            });
            res.status(201).send(user);
        } catch (error) {
            res.status(500).send(error);
        }
    }

    async login(req, res) {
        const { username, password } = req.body;
        const user = await UserRepository.findByUsername(username);

        if (!user || !await bcrypt.compare(password, user.password)) {
            return res.status(401).send({ message: 'Authentication failed' });
        }

        const token = jwt.sign({ id: user._id }, 'secret', { expiresIn: '1h' });
        res.send({ token });
    }
}

module.exports = new UserController();
