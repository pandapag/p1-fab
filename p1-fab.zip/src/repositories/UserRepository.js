const User = require('../models/User');

class UserRepository {
    constructor(db) {
        this.db = db;
    }

    async findUserByEmail(email) {
        return this.db.collection('usuarios').findOne({ email });
    }

    async addUser(user) {
        return this.db.collection('usuarios').insertOne(user);
    }
}

module.exports = UserRepository;
